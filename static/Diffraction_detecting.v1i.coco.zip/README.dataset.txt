# Diffraction_detecting > 2023-04-12 4:15pm
https://universe.roboflow.com/ist-ldjvv/diffraction_detecting

Provided by a Roboflow user
License: CC BY 4.0

